from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import PlayStation, Game, Penyewaan
from django.utils import timezone

def index(request):
    """Halaman utama"""
    ps_terbaru = PlayStation.objects.filter(status='tersedia')[:6]
    games_terbaru = Game.objects.all()[:8]
    context = {
        'ps_terbaru': ps_terbaru,
        'games_terbaru': games_terbaru,
    }
    return render(request, 'rentals/index.html', context)

def daftar_ps(request):
    """Halaman daftar PlayStation"""
    tipe_filter = request.GET.get('tipe', '')
    if tipe_filter:
        ps_list = PlayStation.objects.filter(tipe=tipe_filter, status='tersedia')
    else:
        ps_list = PlayStation.objects.filter(status='tersedia')
    
    context = {
        'ps_list': ps_list,
        'tipe_aktif': tipe_filter,
    }
    return render(request, 'rentals/daftar_ps.html', context)

def detail_ps(request, ps_id):
    ps = get_object_or_404(PlayStation, id=ps_id)
    
    if request.method == 'POST':
        nama_penyewa = request.POST.get('nama_penyewa')
        no_telepon = request.POST.get('no_telepon')
        durasi = request.POST.get('durasi')
        
        # Hitung total harga berdasarkan jenis layanan dan durasi
        if ps.jenis_layanan == 'rental':
            if durasi == '1_jam':
                total_harga = ps.rental_per_jam
            elif durasi == '3_jam':
                total_harga = ps.rental_per_3jam
            elif durasi == '6_jam':
                total_harga = ps.rental_per_6jam
            else:
                total_harga = ps.rental_per_12jam
        else:
            if durasi == '12_jam':
                total_harga = ps.sewa_per_12jam
            else:
                total_harga = ps.sewa_harian
        
        penyewaan = Penyewaan.objects.create(
            ps=ps,
            nama_penyewa=nama_penyewa,
            no_telepon=no_telepon,
            durasi=durasi,
            total_harga=total_harga,
            status='pending'
        )
        
        messages.success(request, f'Pesanan berhasil dibuat! Total: Rp {total_harga:,.0f}')
        return redirect('detail_ps', ps_id=ps_id)
    
    context = {'ps': ps}
    return render(request, 'rentals/detail_ps.html', context)