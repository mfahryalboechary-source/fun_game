from django.urls import path
from . import views

app_name = 'rentals'

urlpatterns = [
    path('', views.index, name='index'),
    path('daftar-ps/', views.daftar_ps, name='daftar_ps'),
    path('detail-ps/<int:ps_id>/', views.detail_ps, name='detail_ps'),
]