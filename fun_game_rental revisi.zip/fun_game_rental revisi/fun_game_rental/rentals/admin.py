from django.contrib import admin
from .models import PlayStation, Game, Penyewaan, Kontak, Paket

@admin.register(PlayStation)
class PlayStationAdmin(admin.ModelAdmin):
    list_display = ['nama', 'tipe', 'jenis_layanan', 'status']
    list_filter = ['tipe', 'jenis_layanan', 'status']
    search_fields = ['nama']
    
    fieldsets = (
        ('Informasi Dasar', {
            'fields': ('nama', 'tipe', 'jenis_layanan', 'gambar', 'status')
        }),
        ('Harga SEWA (Bawa Pulang)', {
            'fields': ('sewa_per_12jam', 'sewa_harian'),
            'classes': ('collapse',),
        }),
        ('Harga RENTAL (Main di Tempat)', {
            'fields': ('rental_per_jam', 'rental_per_3jam', 'rental_per_6jam', 'rental_per_12jam'),
            'classes': ('collapse',),
        }),
        ('Lainnya', {
            'fields': ('spesifikasi',),
        }),
    )

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ['nama', 'tahun_rilis']
    search_fields = ['nama']

@admin.register(Penyewaan)
class PenyewaanAdmin(admin.ModelAdmin):
    list_display = ['nama_penyewa', 'ps', 'durasi', 'total_harga', 'status']
    list_filter = ['status']
    search_fields = ['nama_penyewa']

@admin.register(Kontak)
class KontakAdmin(admin.ModelAdmin):
    list_display = ['telepon', 'email']

@admin.register(Paket)
class PaketAdmin(admin.ModelAdmin):
    list_display = ['nama', 'harga', 'aktif', 'dibuat_pada']
    list_filter = ['aktif']
    search_fields = ['nama', 'deskripsi']
    list_editable = ['harga', 'aktif']
    fieldsets = (
        ('Informasi Paket', {
            'fields': ('nama', 'deskripsi', 'gambar', 'harga', 'aktif')
        }),
    )
